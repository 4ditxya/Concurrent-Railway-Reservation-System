package com.train.reservation.system.payment;
import java.util.*;
public abstract class PaymentMode {
    Scanner sc=new Scanner(System.in);

    abstract void Paymentmode();
}


