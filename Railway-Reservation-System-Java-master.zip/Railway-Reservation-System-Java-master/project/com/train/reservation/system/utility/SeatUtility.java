package com.train.reservation.system.utility;

public interface SeatUtility {
    
    public String getSeatAvailability();
}
